-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2018 at 12:52 PM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id6041626_coachingdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `names` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `meassage` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `learning_history`
--

CREATE TABLE `learning_history` (
  `id` int(11) NOT NULL,
  `sid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `m_id` varchar(250) NOT NULL,
  `decision` varchar(250) NOT NULL DEFAULT 'pending',
  `approved_user` varchar(250) NOT NULL,
  `dates` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `teacher_decision` varchar(250) NOT NULL DEFAULT 'Inactif'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `learning_history`
--

INSERT INTO `learning_history` (`id`, `sid`, `tid`, `m_id`, `decision`, `approved_user`, `dates`, `teacher_decision`) VALUES
(1, 1, 1, '3', 'pending', '', '2018-05-23 15:06:52', ''),
(2, 1, 1, '4', 'approved', '', '2018-05-23 15:09:38', ''),
(3, 1, 1, '5', 'approved', '', '2018-05-23 15:42:24', 'Inactif'),
(4, 1, 2, '9', 'approved', '', '2018-05-26 09:05:26', 'Inactif'),
(5, 2, 3, '10', 'approved', '', '2018-05-26 16:27:26', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `modulecontents`
--

CREATE TABLE `modulecontents` (
  `id` int(11) NOT NULL,
  `m_id` int(11) NOT NULL,
  `Course_level` varchar(250) NOT NULL,
  `course_details` varchar(250) NOT NULL,
  `course_tutorial` varchar(1000) NOT NULL,
  `publication_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modulecontents`
--

INSERT INTO `modulecontents` (`id`, `m_id`, `Course_level`, `course_details`, `course_tutorial`, `publication_date`) VALUES
(2, 8, 'arrays', 'thisese dynamic', 'ipmc.pdf', '2018-05-21'),
(3, 3, 'fifo', 'nhhfhhfhhhfdnfbfbdf', 'b.jpeg', '2018-05-23'),
(5, 4, 'jhfhfhfh', 'jfghfhhfhfhhhfhdhdhfhhdhfhf', 'coaching.zip', '2018-05-23'),
(6, 4, 'itsme', 'mamamammamama munyana', 'IPRC East Online Final projects reference.docx', '2018-05-23'),
(8, 3, 'kkdkdkkdkdk', 'kkdkdkdkdk', 'WhatsApp Image 2018-02-25 at 19.48.40.jpeg', '2018-05-23'),
(11, 10, 'chap 1.introduction to java', 'thisis thisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisisthisist', 'Oracle.Prep4sure.1z0-071.v2016-07-12.by.Lana.48q.pdf', '2018-05-26');

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `m_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `module_name` varchar(250) NOT NULL,
  `module_details` varchar(250) NOT NULL,
  `category` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`m_id`, `teacher_id`, `module_name`, `module_details`, `category`) VALUES
(3, 1, 'matlab', 'jfmvbbsbbbsbsbbsbs', 'Programming'),
(4, 1, 'kinyarwanda', 'locajjjjjjddlocajjjjjjddlocajjjjjjddlocajjjjjjddlocajjjjjjddlocajjjjjjdd', 'DataBase-or-related-courses'),
(5, 1, 'kenya', 'hfhhfhhfhhdhfhhfhdhhff', 'Programming'),
(6, 1, 'nsnnsnskkdkkdkdk', 'jdjjjjdjdjjdjdjjdjdjfkfkdkkfkd', 'Pc maintenance'),
(7, 1, 'c#', 'with this course is about mmmwith this course is about mmmwith this course is about mmmwith this course is about mmmwith this course is about mmmwith this course is about mmmwith this course is about ', 'Programming'),
(8, 4, 'switching', 'hdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhdhdhhdhd', 'Networking'),
(9, 2, 'Realtional Database', 'in this module I have gathered different information about relational database and mysql queries that can help someone to be familiar with sql commands like queries on single table and ofcourse on mul', 'DataBase-or-related-courses'),
(10, 3, 'java Spring boot', 'spring this whatspring this whatspring this whatspring this whatspring this whatspring this whatspring this whatspring this whatspring this whatspring this whatspring this whatspring this whatspring t', 'Programming'),
(11, 6, 'java EE', 'java eee is advanced java frame work that is used to develop web applications using java is good since it not a bit different with java but having features to enable it to work as web application we s', 'DataBase-or-related-courses'),
(12, 9, 'Low and legal ethics', 'this module will help students to learn all about low in order to know where and what to do when his right is viorated', 'DataBase-or-related-courses'),
(13, 12, 'Low and legal ethics', 'hfhfhfhhffs', 'Programming'),
(14, 12, 'java ee', 'hfhfjhfjhdhhfjdhfhjd', 'Programming'),
(15, 12, 'c+++', 'dskdhfsuduhfdsusduhdsosdu', 'Programming');

-- --------------------------------------------------------

--
-- Table structure for table `specialusers`
--

CREATE TABLE `specialusers` (
  `id` int(11) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `duty` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialusers`
--

INSERT INTO `specialusers` (`id`, `firstname`, `lastname`, `duty`, `email`, `password`) VALUES
(1, 'lolo20', 'lolo3', 'admin', 'nelly@gmail.com', '12345612');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `first_name` varchar(250) NOT NULL,
  `last_name` varchar(250) NOT NULL,
  `telephone` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT 'inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `last_name`, `telephone`, `email`, `password`, `status`) VALUES
(1, 'claire ', 'Akamanzi', '0781953', 'kca@gmail.com', '0784125', 'active'),
(2, 'kamanzi', 'alex', '0789455222', 'alex@gmail.com', '412597656', 'active'),
(3, 'juliette', 'ishimwe', '07894524', 'ij@gmail.com', '123456789', 'active'),
(4, 'kamanzi', 'micheal', '0789456123', 'hmwisenneza@gmail.com', '07894561230', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `fname` varchar(250) NOT NULL,
  `lname` varchar(250) NOT NULL,
  `telephone` varchar(250) NOT NULL,
  `email_address` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `status` varchar(250) NOT NULL DEFAULT 'inactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `fname`, `lname`, `telephone`, `email_address`, `password`, `status`) VALUES
(1, 'kamana', 'febronie', '07815499032', 'hmwiseneza@gmail.com', '0127894562', 'active'),
(2, 'ama', 'kaka', '0789456123', 'abbank@gmail.com', '123456789', 'active'),
(3, 'mukesha', 'aline', '07894561230', 'h@gmail.com', '123456789', 'inactive'),
(4, 'honore', 'mwiseneza', '078945612301', 'hmakai@gmailc.com', '1234567989', 'active'),
(5, 'nana', 'nono', '078945612', 'kn@gmail.com', '12340', 'active'),
(6, 'fidel', 'fifi', '0781442', 'hon@gmail.com', '12345', ''),
(7, 'K', 'K', '0786467367', 'gd@gmail.com', 'kk', ''),
(8, 'Aline', 'Kayitesi', '+0785454210', 'Kayitesi@gmail.com', '111111', ''),
(9, 'Niyotwagira', 'Clementine', '0722222222', 'Niyotwagira@gmail.com', '444444', ''),
(11, 'jacky', 'uwama', '0784540261', 'jecky@gmail.com', '666666', ''),
(12, 'Marceline', 'Niyomukesha', '+250783221', 'Marceline@gmail.com', '333333', ''),
(13, 'chacha', 'uwama', '07845402612', 'hew@gmail.com', '11111', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `learning_history`
--
ALTER TABLE `learning_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modulecontents`
--
ALTER TABLE `modulecontents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`m_id`);

--
-- Indexes for table `specialusers`
--
ALTER TABLE `specialusers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `telephone` (`telephone`,`email`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_address` (`email_address`),
  ADD UNIQUE KEY `telephone` (`telephone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `learning_history`
--
ALTER TABLE `learning_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `modulecontents`
--
ALTER TABLE `modulecontents`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `specialusers`
--
ALTER TABLE `specialusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
