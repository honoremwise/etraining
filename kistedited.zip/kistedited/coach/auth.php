<?php
session_start();
if(!isset($_SESSION["email"])){
echo"<script>function redirect(){
window.location='login.php';
}setInterval(redirect,1000);</script>";
exit(); }
?>