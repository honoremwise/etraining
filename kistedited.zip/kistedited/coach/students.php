     <?php
include('auth.php');
include("connection.php");
$username=$_SESSION['email'];
$id="";$firstname="";$lastname="";$telephone="";$email_address="";$password="";
$stnts=("SELECT * FROM students WHERE telephone='$username' OR email= '$username'");
$qrys=mysqli_query($conn,$stnts);
//echo $username;
$row=mysqli_fetch_array($qrys);
$id=$row['id'];
$firstname=$row['first_name'];
$lastname=$row['last_name'];
$telephone=$row['telephone'];
$email_address=$row['email'];
$password=$row['password'];

$m="";                                                      

?> 

<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>Training-link</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">


        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- PrettyPhoto -->
        <link rel="stylesheet" href="assets/css/prettyPhoto.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>


    </head>
    <body>
    <!-- NAVBAR
    ================================================== -->

    <header class="main-header">
        
       <!-- NAVBAR
    ================================================== -->
       <nav class="navbar navbar-static-top">

            <div class="navbar-top">

              <div class="container">
                  <div class="row">

                    <div class="col-sm-6 col-xs-12">

                        <ul class="list-unstyled list-inline header-contact">
                            <li> <i class="fa fa-phone"></i> <a href="tel:">+250 788 503 881  </a> </li>
                             <li> <i class="fa fa-envelope"></i> <a href="mailto:contact@sadaka.org">contactus@Ur.ac.rw</a> </li>
                       </ul> <!-- /.header-contact  -->
                      
                    </div>

                    <div class="col-sm-6 col-xs-12 text-right">

                        <ul class="list-unstyled list-inline header-social">

                            <li> <a href="#" target="_blank"> <i class="fa fa-facebook"></i> </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-twitter"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-google"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-youtube"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa fa-pinterest-p"></i>  </a> </li>

                       </ul> <!-- /.header-social  -->
                      
                    </div>


                  </div>
              </div>

            </div>

            <div class="navbar-main">
              
              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                  </button>
                  
<!--                  <a class="navbar-brand" href="index.php"><img src="assets/images/sadaka-logo.png" alt=""></a>-->
                  
                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">

                  <ul class="nav navbar-nav">

                 


                

                    <li><a href="logout.php">Signout</a></li>
                     

                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->
              
            </div> <!-- /.navbar-main -->


        </nav> 

    </header> <!-- /. main-header -->


	
	<div class="main-container">

		<div class="our-causes fadeIn animated">

	        <div class="container">

	           <br>
            <div class="row">

	                          <div class="col-md-12 fadeIn animate-onscroll">

					<h2 class="title-style-2"><center><?php echo $lastname." ".$firstname."'S DASH BOARD"; ?><span class="title-under"></span></h2>
<br><br>
					
						<div role="tabpanel">

							  <!-- Nav tabs -->
							  <ul class="nav nav-tabs" role="tablist">
							    <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">LIST OF COURSES</a></li>
							    <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">ON GOING COURSES</a></li>
<!--							    <li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">LEARNING HISTORY</a></li>-->
							    <li role="presentation"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">PERSONAL INFORMATION</a></li>
							  </ul>
<?php
if(isset($_GET['more']))
 {
                $id=$_GET['more'];
echo '     <div class="col-md-3">
<div class="reasons-col animate-onscroll fadeIn" style="height:280px;bor">
                     <center>
                     <a href="Students.php" class="btn btn-primary">Click To Go Back</a> 
             <br><br><br><br><br><br><br><br><br><br>
    <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#donateModal">Click  view Contents</a>                 
                     </center>
                  </div>
                    
                </div> ';
                }
//some problem is within the desing
?>             
                       							  <!-- Tab panes -->
							  <div class="tab-content">
							    <div role="tabpanel" class="tab-pane active" id="home">
              <?php
$m_id="";$teacher_id="";$module_name="";$module_details="";$category="";
$ib="select * from modules";
$modules=mysqli_query($conn,$ib);
$num=mysqli_num_rows($modules);

if($num>0)
{
while($recs=mysqli_fetch_array($modules))
{
$m_id=$recs['m_id'];
$teacher_id=$recs['teacher_id'];
$module_name=$recs['module_name'];
 $module_details=$recs['module_details'];
  $category=$recs['category'];
    if($category=="Programming"){
    echo' <div class="col-md-3">

                    <div class="reasons-col animate-onscroll fadeIn">

         <h1><i class="fa fa-file-code-o" style="font-size:700%"></i></h1>
                        <div class="reasons-titles">

                            <h3 class="reasons-title">'.$module_name.'</h3>
                            <h5 class="reason-subtitle">Category:'.$category.'</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">';
    echo"<center><h4><u>Module Short Description</u><h4></center>";                        
 echo'

                                <p> '.$module_details.'
                                                                </p>

                             ';
                     echo"<h1> <a href='students.php?more={$recs['m_id']}'><i class='fa fa-eye' style='color:white;'></i></a><h1>       
                        </div>
                    </div>
                    
                </div>";
    
    }
    else if($category=="DataBase-or-related-courses")
    {
    echo' <div class="col-md-3">

                    <div class="reasons-col animate-onscroll fadeIn">

         <h1><i class="fa fa-database" style="font-size:700%"></i></h1>
                        <div class="reasons-titles">

                            <h3 class="reasons-title">'.$module_name.'</h3>
                            <h5 class="reason-subtitle">Category:'.$category.'</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">';
    echo"<center><h4><u>Module Short Description</u><h4></center>";                        
 echo'

                                <p> '.$module_details.'
                                                                </p>

                              ';
                   echo"<h1> <a href='students.php?more={$recs['m_id']}'><i class='fa fa-eye' style='color:white;'></i></a><h1>       
                        </div>
                    </div>
                    
                </div>";
    
    }
    else if($category=="Pc maintenance")
   {
    echo' <div class="col-md-3">

                    <div class="reasons-col animate-onscroll fadeIn">

         <h1><i class="fa fa-wrench" style="font-size:700%"></i></h1>
                        <div class="reasons-titles">

                            <h3 class="reasons-title">'.$module_name.'</h3>
                            <h5 class="reason-subtitle">Category:'.$category.'</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">';
    echo"<center><h4><u>Module Short Description</u><h4></center>";                        
 echo'
                                <p> '.$module_details.'
                                                                </p>
';
                   echo"<h1> <a href='students.php?more={$recs['m_id']}'><i class='fa fa-eye' style='color:white;'></i></a><h1>      
                        </div>
                    </div>
                    
                </div>";
    
    }
else
{
    echo' <div class="col-md-3">

                    <div class="reasons-col animate-onscroll fadeIn">

         <h1><i class="fa fa-wifi" style="font-size:700%"></i></h1>
                        <div class="reasons-titles">

                            <h3 class="reasons-title">'.$module_name.'</h3>
                            <h5 class="reason-subtitle">Category:'.$category.'</h5>
                            
                        </div>

                        <div class="on-hover hidden-xs">';
    echo"<center><h4><u>Module Short Description</u><h4></center>";                        
 echo'
                                <p> '.$module_details.'
                                                                </p>

                                ';
                  echo"<h1> <a href='students.php?more={$recs['m_id']}'><i class='fa fa-eye' style='color:white;'></i></a><h1>      
                        </div>
                    </div>
                    
                </div>";
    echo"<br>";
    
    }

}

}
                      
                                    ?>
                                                
							</div>
							    <div role="tabpanel" class="tab-pane" id="profile">
							    		    	     <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
           <!-- project details -->   
            <?php
include("connection.php");
             if(isset($_POST['saves']))
{
   echo "Data not saved and uploading";  
$dates=date('Y-m-d'); 
$topic=$_POST['topic'];
$objectives=$_POST['objectives'];
$scope=$_POST['scope'];    
$supevisor=$_POST['supevisor'];
     $supid="";  
$getsup=explode('-',$supevisor);
$supid=$getsup[0];
$projectfiles_array = $_FILES['file_array']['name'];
$tmp_name_array = $_FILES['file_array']['tmp_name'];
$type_array = $_FILES['file_array']['type'];
$size_array = $_FILES['file_array']['size'];
$error_array = $_FILES['file_array']['error'];
    
 echo $dates.$topic.$objectives.$scope.$supevisor.$supid.$projectfiles_array[0];  
    
    
for($i = 0 ;$i < count($tmp_name_array); $i++){ 
    if(move_uploaded_file($tmp_name_array[$i],"projectfiles/".$projectfiles_array[$i])){
echo $projectfiles_array[$i]."is uploaded successfully ,,,,,,,,,,,,,,";

}
                                            else{
echo "Data not saved and uploading".$project_files[$i]."failed<br>";
                                            }
                                           }    
$binserts="insert  into `projects`
(topic,project_report,video_tutorial,project_file,objectives,sid,scope_summary)
values
('$topic','$project_files[0]','$project_files[1]','$project_files[2]','$objectives','$supid','$scope')";
$bresult = mysqli_query($conn,$binserts);     
                 if($bresult)
    {
      echo "<i class='fa fa-info' style='color:red;'>Project uploaded successfully123</i>";
        echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,1000);</script>";
   }
    else
         echo "hihihhhhhhhhhhhhhhhhhhhhhhh".mysqli_error($conn);                                  

             }
             
   
              
              ?>
              <!-- project details -->
    <center><h4 class="modal-title" id="donateModalLabel"><?php
        
        echo $m;?>Learning Courses
        </h4></center>
             
          </div>
          <div class="modal-body">
  <div role="tabpanel" class="tab-pane" id="profile">
      <table class="table table-style-1">
					      <thead>
					        <tr>
					          <th>#</th>
					          <th>Module</th>
					          <th>Subscription date</th>
					          <th>Acess to contents</th>
					        </tr>
					      </thead>
					      <tbody>
		<?php
$vd="select * from learning_history where sid=$id";
$ssql=mysqli_query($conn,$vd);
$module_name="";
while($srow=mysqli_fetch_array($ssql))
{
$hid=$srow['id'];
$sid=$srow['sid'];
$tid=$srow['tid'];
$m_id=$srow['m_id'];    
$dates=$srow['dates'];
 $teacher_decision=$srow['teacher_decision'];
$vs="select * from modules where m_id=$m_id";
$msql=mysqli_query($conn,$vs);   
    while($mrecs=mysqli_fetch_array($msql))
    {
    $module_name=$mrecs['module_name'];
        }
    echo'<tr>
					          <th scope="row"><?php
                                  echo $hid."h".$sid;
                                  ?></th>
					          <td>'.$module_name.'</td>
					          <td>'.$dates.'</td>
					          <td>'.$teacher_decision.'</td>
					        </tr>'; 
}
      
      
      ?>					    		
						
					       
					      </tbody>
					    </table></div>
            
          </div>
        </div>
      </div>
						</div>
							    <div role="tabpanel" class="tab-pane" id="messages">
							    	Client payement infos</div>
							    <div role="tabpanel" class="tab-pane" id="settings">
							    	   <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
    <center><h4 class="modal-title" id="donateModalLabel">PERSONAL DETAILS</h4></center>
          </div>
          <div class="modal-body">

                <form class="form-donation" action="#" method="post">
   <div class="row">

                          <div class="form-group col-md-2">
                              
                            </div> 
                            <div class="form-group col-md-10 ">
 
                            </div>

                        </div>
                       <div class="row">

                          <div class="form-group col-md-2">
                               <label> Email:</label>
                            </div> 
                            <div class="form-group col-md-10 ">
  <input type="text" class="form-control" id="amount" name="username" value="<?php echo $email_address?>"required>
                            </div>

                        </div>  
                    <div class="row">

                          <div class="form-group col-md-2">
                               <label> Telephone:</label>
                            </div> 
                            <div class="form-group col-md-10 ">
  <input type="text" class="form-control" id="amount" name="username" value="<?php echo $firstname?>"required>
                            </div>

                        </div>


                        <div class="row">
                            <div class="form-group col-md-2">
                               <label> Lastname:</label>
                            </div>
                            <div class="form-group col-md-10">
                                <input type="text" class="form-control" name="lname" value="<?php echo $lastname?>">
                            </div>

                           
                        </div>
                    <div class="row">
                            <div class="form-group col-md-2">
                               <label> Telephone:</label>
                            </div> <div class="form-group col-md-10">
                                <input type="text" class="form-control" name="password" value="<?php echo $telephone?>">
                            </div>

                           
                        </div>

                    <div class="row">

                            <div class="form-group col-md-4">
                             
                            </div>
                            <div class="form-group col-md-4">
                               <CENTER><button type="submit" class="btn btn-primary pull-right" name="lgn" >UPDATE</button></CENTER> 
                            </div>
                            <div class="form-group col-md-4">
                              
                            </div>

                        </div>



                       
                    
                </form>
            
          </div>
        </div>
      </div></div>
							  </div>

						</div>

						<p></p>
					

				</div>
                    
              
	            </div>

	         </div>
	        
	    </div> <!-- /.our-causes -->

		


	</div> <!-- /.main-container  -->

 <footer class="main-footer">

        <div class="footer-top">
            
        </div>


        <div class="footer-main">
            <div class="container">
                
                <div class="row">
                    <div class="col-md-4">

                        
                            
                        </div>

                    </div>

                                      <div class="clearfix"></div>



                </div>
                
                
            </div>

            
        </div>

        <div class="footer-bottom">

            <div class="container text-right">
             <br>
            </div>
        </div>
        
    </footer>


        <!-- Donate Modal -->
          <div class="modal fade" id="donateModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">More details about this Courses </h4>
          </div>
          <div class="modal-body">
             <?php
           
if(isset($_GET['more']))
 {
    $id=$_GET['more'];
$msql=mysqli_query("select * from modules where m_id=$id");
    $read=mysqli_fetch_array($msql);        
        $m_id=$read['m_id'];
         $teacher_id=$read['teacher_id'];
            $module_name=$read['module_name'];
            $module_details=$read['module_details'];
          $mcontentsql=mysqli_query("select * from modulecontents where m_id=$m_id");
            $mCount=mysqli_num_rows($mcontentsql);
            if($mcontentsql&&($mCount>0))
            {
echo "<h3>The module have ".$mCount." Content(s) that are the following  </h3>";
                while($retrieve=mysqli_fetch_array($mcontentsql))
                {
$Course_level=$retrieve['Course_level'];
$publication_date=$retrieve['publication_date'];
echo"<h3><i class='fa fa-minus' style='color:black;'>  ".$Course_level."</i> </h3><br>";
                }
            }
            else{
                 echo "<h1><i class='fa fa-warning' style='color:black;'> The module does not have contents yet</i></h1>";
  echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,1000);</script>";
            }
                }
?>

              <br> <br>
              <div class="row">
            <div class="form-group col-md-6">
                <a href="students.php"> <button type="reset" class="btn btn-primary pull-right" name="donateNow" >Home</button></a> 
                            </div>
                  <div class="form-group col-md-6">
   <?php echo" <a href='test.php?sub={$m_id}'> <button type='submit' class='btn btn-primary pull-left' name='donateNow' >Subscribe</button></a>";
                      
                      if (isset($_GET['sub']))
{
                           echo $teacher_id.$id;
                          $mid=$_GET['sub'];
$ins="insert into learning_history(sid,tid,m_id)values($id,20,$mid)";
 $mysq=mysqli_query($ins);
if($mysq)
    {
  echo "<h1><i class='fa fa-info' style='color:black;'> Data inserted</i></h1>";
  echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,1000);</script>";
    }
                          else{
echo "<h1><i class='fa fa-info' style='color:black;'>".mysqli_error()."</i></h1>";
  echo"<script>function redirect(){
window.location='studentss.php';
}setInterval(redirect,10000);</script>";
                          
                          }

}
                      ?>                           
                            </div>
              </div>
          </div>
        </div>
      </div>

    </div>
<!--
    <div class="modal fade" id="donateModal" tabindex="-1" role="dialog" aria-labelledby="donateModalLabel" aria-hidden="true">

      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="donateModalLabel">DONATE NOW</h4>
          </div>
          <div class="modal-body">

                <form class="form-donation">

                        <h3 class="title-style-1 text-center">Thank you for your donation <span class="title-under"></span>  </h3>

                        <div class="row">

                            <div class="form-group col-md-12 ">
                                <input type="text" class="form-control" id="amount" placeholder="AMOUNT(€)">
                            </div>

                        </div>


                        <div class="row">
                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="firstName" placeholder="First name*">
                            </div>

                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="lastName" placeholder="Last name*">
                            </div>
                        </div>


                        <div class="row">

                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="email" placeholder="Email*">
                            </div>

                            <div class="form-group col-md-6">
                                <input type="text" class="form-control" name="phone" placeholder="Phone">
                            </div>

                        </div>

                        <div class="row">

                            <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="address" placeholder="Address">
                            </div>

                        </div>


                        <div class="row">

                            <div class="form-group col-md-12">
                                <textarea cols="30" rows="4" class="form-control" name="note" placeholder="Additional note"></textarea>
                            </div>

                        </div>

                        <div class="row">

                            <div class="form-group col-md-12">
                                <button type="submit" class="btn btn-primary pull-right" name="donateNow" >DONATE NOW</button>
                            </div>

                        </div>



                       
                    
                </form>
            
          </div>
        </div>
      </div>

    </div>  /.modal 
-->
       
        <!-- jQuery -->
        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="assets/js/jquery-1.11.1.min.js"><\/script>')</script>

        <!-- Bootsrap javascript file -->
        <script src="assets/js/bootstrap.min.js"></script>

        <!-- PrettyPhoto javascript file -->
        <script src="assets/js/jquery.prettyPhoto.js"></script>



        <!-- Google map  -->
        <script src="http://maps.google.com/maps/api/js?sensor=false&amp;libraries=places" type="text/javascript"></script>


        <!-- Template main javascript -->
        <script src="assets/js/main.js"></script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='//www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X');ga('send','pageview');
        </script>
    </body>
</html>
