<?php  session_start();?>
<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>Training-link</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">


        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- PrettyPhoto -->
        <link rel="stylesheet" href="assets/css/prettyPhoto.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>


    </head>
    <body>
    <!-- NAVBAR
    ================================================== -->

    <header class="main-header">
        
       <!-- NAVBAR
    ================================================== -->
       <nav class="navbar navbar-static-top">

            <div class="navbar-top">

              <div class="container">
                  <div class="row">

                    <div class="col-sm-6 col-xs-12">

                        <ul class="list-unstyled list-inline header-contact">
                            <li> <i class="fa fa-phone"></i> <a href="tel:">+2503015496 </a> </li>
                             <li> <i class="fa fa-envelope"></i> <a href="#">Ur.ac.rw</a> </li>
                       </ul> <!-- /.header-contact  -->
                      
                    </div>

                    <div class="col-sm-6 col-xs-12 text-right">

                        <ul class="list-unstyled list-inline header-social">

                            <li> <a href="#" target="_blank"> <i class="fa fa-facebook"></i> </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-twitter"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-google"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-youtube"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa fa-pinterest-p"></i>  </a> </li>

                       </ul> <!-- /.header-social  -->
                      
                    </div>


                  </div>
              </div>

            </div>

            <div class="navbar-main">
              
              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                  </button>
                  
                  <a class="navbar-brand" href="index.php"><img src="assets/images/sadaka-logo.png" alt=""></a>
                  
                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">
 <ul class="nav navbar-nav">

                    <li><a href="index.php">HOME</a></li>
                      <li class="has-child"><a href="signup.php">SIGNUP</a></li>

                </li>

                    <li><a href="login.php">SIGN IN</a></li>
                      <li><a href="contact.php">CONTACT US</a></li>

                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->
              
            </div> <!-- /.navbar-main -->


        </nav> 

    </header> <!-- /. main-header -->
	<div class="main-container">

		<div class="our-causes fadeIn animated">

	        <div class="container">

	                <div class="row">

	   <div class="col-md-3 col-sm-6">
          
           <?php 
   include("connection.php");
    if(isset($_POST['lgn']))
        {
 	$username =$_POST['username'];
 	$password =$_POST['password'];
	             //to find admin users
$users = "select * from specialusers where email='$username' and password='$password'";
$user_result = mysqli_query($conn,$users) or die(mysqli_error($conn));
$userrecs = mysqli_num_rows($user_result);
                //to find students
$students_recs = "select * from `students` where (email='$username' or 
telephone='$username')and password='$password'";
$students_result = mysqli_query($conn,$students_recs) or die(mysqli_error($conn));
$students_counter = mysqli_num_rows($students_result);        
           
           //to find supervisors  
$supervisors_recs = "select * from `teachers` where (email_address='$username' or 
telephone='$username')and password='$password'";
	$result = mysqli_query($conn,$supervisors_recs) or die(mysqli_error($conn));
	$supervisors_counter = mysqli_num_rows($result);
        
        if($userrecs>0)
        {
	    $_SESSION['email'] = $username;
           
            echo"<script>function redirect(){
window.location='manage.php';
}setInterval(redirect,1000);</script>";
    }
else if($supervisors_counter>0)
        {
            $_SESSION['email'] = $username;
 echo"<script>function redirect(){
window.location='trainerspage.php';
}setInterval(redirect,1000);</script>";
            
          }
else if($students_counter>0)
        {
            $_SESSION['email'] = $username;
            echo"<script>function redirect(){
window.location='students.php';
}setInterval(redirect,1000);</script>";
          }
        
        
else{
	 echo"<center><font color='red'><h1> error with your credithentials</h1></font></center>"; 
     echo"<script>function redirect(){
window.location='login.php';
}setInterval(redirect,1000);</script>";
	}
    }
           ?>
                    </div>
           <div class="col-md-3 col-sm-6">
<br><br><br><br>
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
    <center><h4 class="modal-title" id="donateModalLabel">AUTHENTICATION FORM</h4></center>
          </div>
          <div class="modal-body">

                <form class="form-donation" action="#" method="post">

                        <div class="row">

                            <div class="form-group col-md-12 ">
                                <input type="text" class="form-control" id="amount" placeholder="Email or Tel" name="username" required>
                            </div>

                        </div>


                        <div class="row">
                            <div class="form-group col-md-12">
                                <input type="password" class="form-control" name="password" placeholder="Password*">
                            </div>

                           
                        </div>

                    <div class="row">

                            <div class="form-group col-md-4">
                             
                            </div>
                            <div class="form-group col-md-4">
                               <CENTER><button type="submit" class="btn btn-primary pull-right" name="lgn" >LOGIN</button></CENTER> 
                            </div>
                            <div class="form-group col-md-4">
                              
                            </div>

                        </div>



                       
                    
                </form>
            
          </div>
        </div>
      </div>

    </div>
		                    
		                </div> 

		              

            </div>

	         </div>
	        
	    </div> <!-- /.our-causes -->

		


	</div> <!-- /.main-container  -->
<?php include("footer.php");?>

   