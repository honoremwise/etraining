              <?php 
include("connection.php");
include'auth.php';
$username=$_SESSION['email'];
$id="";$firstname="";$lastname="";$telephone="";$email_address="";$password="";
$dc="select * from specialusers where email ='$username'";
$qry=mysqli_query($conn,$dc);
//echo $username;
$row=mysqli_fetch_array($qry);
$id=$row['id'];
$firstname=$row['firstname'];
$lastname=$row['lastname'];
$telephone=$row['duty'];
$email_address=$row['email'];
$password=$row['password'];

$m="";  
?> 
<!DOCTYPE html>
<html class="no-js">
    <head>
        <meta charset="utf-8">
        <title>Training-link</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Fonts -->
        <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
        <link href='http://fonts.googleapis.com/css?family=Dosis:400,700' rel='stylesheet' type='text/css'>

        <!-- Bootsrap -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">


        <!-- Font awesome -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">

        <!-- PrettyPhoto -->
        <link rel="stylesheet" href="assets/css/prettyPhoto.css">

        <!-- Template main Css -->
        <link rel="stylesheet" href="assets/css/style.css">
        
        <!-- Modernizr -->
        <script src="assets/js/modernizr-2.6.2.min.js"></script>


    </head>
    <body>
    <!-- NAVBAR
    ================================================== -->

    <header class="main-header">
        
       <!-- NAVBAR
    ================================================== -->
       <nav class="navbar navbar-static-top">

            <div class="navbar-top">

              <div class="container">
                  <div class="row">

                    <div class="col-sm-6 col-xs-12">

                        <ul class="list-unstyled list-inline header-contact">
                            <li> <i class="fa fa-phone"></i> <a href="tel:">+2503012749 213 </a> </li>
                             <li> <i class="fa fa-envelope"></i> <a href="mailto:contact@ur.ac.rw">contact@ur.ac.rw</a> </li>
                       </ul> <!-- /.header-contact  -->
                      
                    </div>

                    <div class="col-sm-6 col-xs-12 text-right">

                     <!--   <ul class="list-unstyled list-inline header-social">

                            <li> <a href="#" target="_blank"> <i class="fa fa-facebook"></i> </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-twitter"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-google"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa-youtube"></i>  </a> </li>
                            <li> <a href="#" target="_blank"> <i class="fa fa fa-pinterest-p"></i>  </a> </li>

                       </ul>  /.header-social  -->
                      
                    </div>


                  </div>
              </div>

            </div>

            <div class="navbar-main">
              
              <div class="container">

                <div class="navbar-header">
                  <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">

                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>

                  </button>
                  
                  
                  
                </div>

                <div id="navbar" class="navbar-collapse collapse pull-right">

                  <ul class="nav navbar-nav">
 <li><a href="logout.php">Signout</a></li>
                      

                  </ul>

                </div> <!-- /#navbar -->

              </div> <!-- /.container -->
              
            </div> <!-- /.navbar-main -->


        </nav> 

    </header> <!-- /. main-header -->
	<div class="main-container">

		<div class="our-causes fadeIn animated">

	        <div class="container">

	                <div class="row">

                        <!--php codes--->
                 
                        
                        
	   <div class="col-md-3 col-sm-6">

		                    <div class="cause">

		                      

		                        <h4 class="cause-title">
                                    
                                    <a href="#">
                                     <u><h1>Personal  Infos</h1></u><br>
                                                                       
                                    </a></h4>
		                        <div class="cause-details">
                       <div class="modal-body">
<?php
                        if(isset($_POST['update']))
                        {
                       $a=$_POST['fnames'];$b=$_POST['lname'];$d=$_POST['password'];    
$cx="update specialusers set firstname='$a',lastname='$b',password='$d'";
$qry=mysqli_query($conn,$cx);
                            if($qry){
                            echo "Update successfully";
                              echo"<script>function redirect(){
window.location='manage.php';
}setInterval(redirect,1000);</script>";
                            }

}
                        ?>
                <form class="form-donation" action="#" method="post">

                        <div class="row">

                          <div class="form-group col-md-2">
                               <label> Email:</label>
                            </div> 
                            <div class="form-group col-md-12 ">
  <input type="text" class="form-control" id="amount" name="username" value="<?php echo $email_address?>" name="ema" disabled>
                            </div>

                        </div> 
                    <div class="row">

                          <div class="form-group col-md-2">
                               <label> Firstname:</label>
                            </div> 
                            <div class="form-group col-md-12 ">
  <input type="text" class="form-control" id="amount" name="fnames" value="<?php echo $firstname?>"required>
                            </div>

                        </div>


                        <div class="row">
                             <div class="form-group col-md-2">
                               <label> Lastname:</label>
                            </div> 
                            <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="lname" value="<?php echo $lastname?>">
                            </div>

                           
                        </div>
                    <div class="row">
                         <div class="form-group col-md-2">
                               <label> Duty:</label>
                            </div> 
                           <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="password" value="<?php echo $telephone?>" disabled>
                            </div>

                           
                        </div> 
                    <div class="row">
                         <div class="form-group col-md-2">
                               <label> Password:</label>
                            </div> 
                           <div class="form-group col-md-12">
                                <input type="text" class="form-control" name="password" value="<?php echo $password?>" >
                            </div>

                           
                        </div>

                    <div class="row">

                            <div class="form-group col-md-4">
                             
                            </div>
                            <div class="form-group col-md-4">
                               <CENTER><button type="submit" class="btn btn-primary pull-right" name="update" >UPDATE</button></CENTER> 
                            </div>
                            <div class="form-group col-md-4">
                              
                            </div>

                        </div>



                       
                    
                </form>
            
          </div>
		                        </div>
                  

		                    </div>                
                        </div>
           
               <div class="col-md-7 col-sm-7">
<br><br>
      <div class="modal-dialog">
        		

				<div class="col-md-12 fadeIn animate-onscroll">
				
					<h2 class="title-style-2"> Admin Dashboard <span class="title-under"></span></h2>

					<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
					  <div class="panel panel-default">
					    <div class="panel-heading" role="tab" id="headingOne">
					      <h4 class="panel-title">
					        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
					          Subscription Request
					        </a>
					      </h4>
					    </div>
					    <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
					      <div class="panel-body">
					  <div class="modal-body">
  <div role="tabpanel" class="tab-pane" id="profile">
      <table class="table table-style-1">
					      <thead>
					        <tr>
					          <th>#</th>
					          <th>Module</th>
					          <th>Subscription date</th>
					          <th>Linking Status</th>
                                <th>Option</th>
					        </tr>
					      </thead>
					      <tbody>
		<?php
$vc="select * from learning_history order by decision DESC";
$ssql=mysqli_query($conn,$vc);
$module_name="";
while($srow=mysqli_fetch_array($ssql))
{
$hid=$srow['id'];
$sid=$srow['sid'];
$tid=$srow['tid'];
$m_id=$srow['m_id'];    
$dates=$srow['dates'];
 $decision=$srow['decision'];
$vz="select * from modules where m_id=$m_id";
$msql=mysqli_query($conn,$vz);   
    while($mrecs=mysqli_fetch_array($msql))
    {
    $module_name=$mrecs['module_name'];
        }
    echo'<tr>
					          <th scope="row"><?php
                                  echo $hid."h".$sid;
                                  ?></th>
					          <td>'.$module_name.'</td>
					          <td>'.$dates.'</td>
					          <td>'.$decision.'</td>';
echo" <td><a href='test.php?aproveh={$hid}' style='align:bottom;'><i class='fa fa-check' style='color:blue;'></i> </a></td>
					        </tr>"; 
}
      
      
      ?>					    		
						
					       
					      </tbody>
					    </table></div>
            
          </div>
					      </div>
					    </div>
					  </div>
					  <div class="panel panel-default">
					    <div class="panel-heading" role="tab" id="headingTwo">
					      <h4 class="panel-title">
					        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
					          Trainers Records
					        </a>
					      </h4>
					    </div>
					    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
					      <div class="panel-body">
					         <table class="table table-style-1">
					      <thead>
					        <tr>
					          <th>#</th>
					          <th>Names</th>
					          
					          <th>Telephone</th>
                                <th>Email</th>
                                <th>Status</th>
                                <th>Option</th>
                                
					        </tr>
					      </thead>
					      <tbody>
		<?php
$xz="select * from teachers";
$ssql=mysqli_query($conn,$xz);
$module_name="";
while($srow=mysqli_fetch_array($ssql))
{
$hid=$srow['id'];
$fname=$srow['fname'];
$lname=$srow['lname'];
$telephone=$srow['telephone'];    
$email_address=$srow['email_address'];
 $status=$srow['status'];   
    echo'<tr>
					        
					          <td>'.$hid.'</td>
                              <td>'.$fname.' '.$lname.'</td>
					         
					          <td>'.$telephone.'</td>
                              <td>'.$email_address.'</td>
        <td>'.$status.'</td>';
                            
echo"<td> <a href='test.php?st_actvate={$hid}'> <i class='fa fa-check'title='activate'></i></a>|
<a href='test.php?st_desactvate={$hid}'><i class='fa fa-lock' title='close'></i></a></td>
					        </tr>";
}
      
      
      ?>					    		
						
					       
					      </tbody>
					    </table>
					      </div>
					    </div>
					  </div>
					  <div class="panel panel-default">
					    <div class="panel-heading" role="tab" id="headingThree">
					      <h4 class="panel-title">
					        <a class="collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
					          Trainees information
					        </a>
					      </h4>
					    </div>
					    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
					      <div class="panel-body">
					      <div class="panel-body">
					         <table class="table table-style-1">
					      <thead>
					        <tr>
					          <th>#</th>
					          <th>F Name</th>
					          <th>L Name</th>
					          <th>Telephone</th>
                                <th>Email</th>
                                <th>Access </th>
					        </tr>
					      </thead>
					      <tbody>
		<?php
$rw="select * from students";
$ssql=mysqli_query($conn,$rw);
$module_name="";
while($srow=mysqli_fetch_array($ssql))
{
$hid=$srow['id'];
$fname=$srow['first_name'];
$lname=$srow['last_name'];
$telephone=$srow['telephone'];    
$email_address=$srow['email'];
 $status=$srow['status'];   
    echo'<tr>
					        
					          <td>'.$hid.'</td>
                              <td>'.$fname.'</td>
					          <td>'.$lname.'</td>
					          <td>'.$telephone.'</td>
                              <td>'.$email_address.'</td>';
echo"<td> <a href='test.php?st_actvate={$hid}'> <i class='fa fa-check'title='activate'></i></a>|
<a href='test.php?st_desactvate={$hid}'><i class='fa fa-times' title='close'></i></a></td>
					        </tr>"; 
}
      
      
      ?>					    		
						
					       
					      </tbody>
					    </table>
					      </div>
					      </div>
					    </div>
					  </div>
					</div>

					<p></p>

				</div>
      </div>

    </div>
		                    
		                </div> 

		              

            </div>

	         </div>
	        
	    </div> <!-- /.our-causes -->

		


	</div> <!-- /.main-container  -->
<?php include("footer.php");?>

   