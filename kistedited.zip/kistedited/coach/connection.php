<?php
$server="localhost";
$user="root";
$pswd="";
$db="id6041626_coachingdb";
$conn=mysqli_connect($server,$user,$pswd,$db);
?>